<?php 

$app_id = '2204624902915529';
$app_secret = '0a965d1a202b430d2d5aba520e177618';
$account_id = 'act_258725951253917';// teste
//$account_id = '';//conta real
$access_token = 'EAAfVGDwzhckBAD2royRGO1Lnls4ds7ESHnVUZAtMQKbfBilCk3YbxkDqsRCHkCw38VmyU6y2mBntZA8tIV8sQSuE3dfBVISiwq9cL20WnFjPIiC3k56afvuSPkVF4yc8lJqD02q9ArxadaqGudkD1O5lrIwkf8FLzmswQ1I6p0SVfQlyP7';