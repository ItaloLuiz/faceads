<?php 

$base_admin = 'faceads/admin/';