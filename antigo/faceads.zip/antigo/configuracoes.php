<?php include 'includes/header.php';?>


<?php include 'includes/menu.php';?>

<div class="container-fluid home">

    <form name="form" id="form" method="post" action="">

        <div class="col-md-6">
            <div class="form-group">
                <label>App ID</label>
                <input type="text" name="" id="" class="form-control" required>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-6">
            <div class="form-group">
                <label>App Secret</label>
                <input type="text" name="" id="" class="form-control" required>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Account ID</label>
                <input type="text" name="" id="" class="form-control" required>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-6">
            <div class="form-group">
                <label>Bussiness ID</label>
                <input type="text" name="" id="" class="form-control" required>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="col-md-6">
            <div class="form-group">
               
                <input type="submit" name="" id="" class="btn btn-primary" value="Salvar dados">
            </div>
        </div>
        <div class="clearfix"></div>


    </form>


</div>



    
<?php include 'includes/footer.php';?>
