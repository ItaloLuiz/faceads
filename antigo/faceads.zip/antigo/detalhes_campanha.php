<?php include 'includes/header.php';?>

<?php include 'includes/menu.php';?>

<div class="container-fluid home">
 <div class="row">

 <div class="col-md-8 centro">
  <div class="panel box-detalhes">
   <div class="panel-heading">
    <a class="btn btn-primary" href="index.php">Voltar</a>
    <h2>Conta <small>IEB - Canoas</small></h2>
   
   </div>
   <div class="panel-body">
       <div class="row">
           <div class="col-md-6">
               <h3>Valor Total</h3>
               <h4>R$ 190,48 </h4>
               <a class="btn btn-primary" href="">Enviar ao BI</a>
           </div>
           <div class="col-md-6">
               <h3>Alcance</h3>
               <h4>21.402</h4>
               <a class="btn btn-primary" href="">Enviar ao BI</a>
           </div>
       </div>
   </div>
   <div class="panel-footer">
   <div class="row">
           <div class="col-md-6">
               <h3>Impressões</h3>
               <h4>34.128 </h4>
               
           </div>
           <div class="col-md-6">
               <h3>Clique no link</h3>
               <h4>300</h4>
             
           </div>
       </div>

   </div>  
  </div> 
 </div>


 
 
 
 </div>
</div>
    
<?php include 'includes/footer.php';?>
